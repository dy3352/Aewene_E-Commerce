from flask import Flask, request, jsonify, render_template, redirect, url_for
import pymysql

app = Flask(__name__)

def db_connection():
    conn = None
    try:
        conn = pymysql.connect(
            host='127.0.0.1',  # Atau gunakan 'localhost'
            port=3306,         # Port default MySQL
            user='root',       # User default MySQL di XAMPP
            password='',       # Password default (kosong di XAMPP, jika tidak diubah)
            database='db_produk',  # Ganti dengan nama database Anda
            cursorclass=pymysql.cursors.DictCursor,
        )
    except pymysql.Error as e:
        print(e)
    return conn

# operasi get
@app.route("/PRODUK", methods=["GET", "POST", "PUT", "DELETE"])
def Produk():
    conn = db_connection()
    cursor = conn.cursor()

    if request.method == "GET":
        cursor.execute("SELECT * FROM PRODUK")
        PRODUK = [
            dict(
                id=row["id"],
                gambar=row["gambar"],
                nama=row["nama"],
                ukuran=row["ukuran"],
                stok=row["stok"],
                harga=row["harga"]
            )
            for row in cursor.fetchall()
        ]
        if PRODUK:
            return jsonify(PRODUK)

    elif request.method == "POST":
        if request.form.get("_method") == "DELETE":
            id_to_delete = request.form.get("id")
            cursor.execute("DELETE FROM PRODUK WHERE id = %s", (id_to_delete,))
            conn.commit()
            return "Data Berhasil Dihapus"

        elif request.form.get("_method") == "PUT":
            id_to_update = request.form.get("id")
            update_gambar = request.form["gambar"]
            update_nama = request.form["nama"]
            update_ukuran = request.form["ukuran"]
            update_stok = request.form["stok"]
            update_harga = request.form["harga"]

            query_update = """UPDATE PRODUK SET
                gambar = %s,
                nama = %s,
                ukuran = %s,
                stok = %s,
                harga = %s
                WHERE id = %s"""

            cursor.execute(query_update, (update_gambar, update_nama, update_ukuran, update_stok, update_harga, id_to_update))
            conn.commit()
            return "Data Berhasil Diupdate"

        else:
            add_gambar = request.form["gambar"]
            add_nama = request.form["nama"]
            add_ukuran = request.form["ukuran"]
            add_stok = request.form["stok"]
            add_harga = request.form["harga"]

            query_insert = """INSERT INTO PRODUK (gambar, nama, ukuran, stok, harga) VALUES (%s, %s, %s, %s, %s)"""


            cursor.execute(query_insert, (add_gambar, add_nama, add_ukuran, add_stok, add_harga))
            conn.commit()
            return "Data Berhasil Ditambahkan"
        
    elif request.method == "PUT":
        update_id = request.form["id"]
        update_gambar = request.form["gambar"]
        update_nama = request.form["nama"]
        update_ukuran = request.form["ukuran"]
        update_stok = request.form["stok"]
        update_harga = request.form["harga"]

        query_update = """UPDATE PRODUK SET
            gambar=%s, nama=%s, ukuran=%s, stok=%s, harga=%s
            WHERE id=%s"""

        cursor.execute(query_update, (update_gambar, update_nama, update_ukuran, update_stok, update_harga, update_id))
        conn.commit()
        return "Data Berhasil Diperbarui"

    elif request.method == "DELETE":
        id = request.form['id']
        query_delete = """DELETE FROM PRODUK WHERE id=%s"""  
        cursor.execute(query_delete, (id,))
        conn.commit()
        return "Data Berhasil Dihapus"

@app.route('/')
def home():
    conn = db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM PRODUK")
    PRODUK = [
        dict(
            id=row["id"],
            gambar=row["gambar"],
            nama=row["nama"],
            ukuran=row["ukuran"],
            stok=row["stok"],
            harga=row["harga"]
        )
        for row in cursor.fetchall()
    ]

    return render_template('home.html', PRODUK=PRODUK)

@app.route('/admin')
def admin():
    conn = db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM PRODUK")
    PRODUK = [
        dict(
            id=row["id"],
            gambar=row["gambar"],
            nama=row["nama"],
            ukuran=row["ukuran"],
            stok=row["stok"],
            harga=row["harga"]
        )
        for row in cursor.fetchall()
    ]

    return render_template('admin.html', PRODUK=PRODUK)


if __name__ == "__main__":
    app.run()