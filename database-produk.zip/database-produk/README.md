install flask (pip install flask)
install pymysql (pip install pymysql)

Jalankan dengan vscode, kemudian klik http link nya
