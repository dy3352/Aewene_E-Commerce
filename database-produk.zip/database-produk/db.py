import pymysql

# Koneksi ke database
conn = pymysql.connect(
    host='127.0.0.1',  # Atau gunakan 'localhost'
    port=3306,         # Port default MySQL
    user='root',       # User default MySQL di XAMPP
    password='',       # Password default (kosong di XAMPP, jika tidak diubah)
    database='db_produk',  # Ganti dengan nama database Anda
    cursorclass=pymysql.cursors.DictCursor,
)

# Inisialisasi kursor
cursor = conn.cursor()

# Definisikan skema tabel untuk data 
sql_query = """CREATE TABLE PRODUK (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gambar TEXT NOT NULL,
    nama TEXT NOT NULL,
    ukuran TEXT NOT NULL,
    stok INT NOT NULL,
    harga INT NOT NULL
)
"""

# Eksekusi perintah SQL untuk membuat tabel
cursor.execute(sql_query)

# Tutup koneksi
conn.close()